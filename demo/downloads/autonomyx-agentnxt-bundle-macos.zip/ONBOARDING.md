# Decide + Langflow Onboarding (Single Flow)

Import this flow first:
- langflow_components/decide/onboarding_flow.json

Additional flows:
- langflow_components/decide/insight_flow.json
- langflow_components/decide/search_flow.json

Start Langflow:
```bash
docker compose -f docker-compose.langflow.yml up -d
```
